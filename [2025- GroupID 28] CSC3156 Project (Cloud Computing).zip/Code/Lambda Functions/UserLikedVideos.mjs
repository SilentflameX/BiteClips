import AWS from "aws-sdk";
import jwt from "jsonwebtoken";
const dynamodb = new AWS.DynamoDB.DocumentClient();

// Verify Cognito Token
async function verifyCognitoToken(token) {
  try {
    console.log("Verifying Cognito token...");
    const decoded = jwt.decode(token, { complete: true });
    if (!decoded) throw new Error("Invalid token");
    console.log("Token verified successfully");
    return true;
  } catch (error) {
    console.error("Invalid Cognito Token:", error);
    return false;
  }
}

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  const token = event.headers.Authorization?.split(" ")[1];
  console.log("Token from headers:", token);
  
  if(!await verifyCognitoToken(token))
  {
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*", // or "http://localhost:8081"
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ message: "Invalid token", error: error.message }), // Include error message in response
    };
  }
  
  let userId, videoId;
  try {
    const body = JSON.parse(event.body);
    userId = body.userId;
    videoId = body.videoId;
    console.log("Parsed userId:", userId);
    console.log("Parsed videoId:", videoId);
  } catch (parseError) {
    console.error("Error parsing event body:", parseError);
    return {
      statusCode: 400,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ message: "Invalid request body" }),
    };
  }

  const params = {
    TableName: 'UserLikedVideos',
    Item: {
      UserID: userId,
      VideoID: videoId
    },
  };

  console.log("DynamoDB put parameters:", JSON.stringify(params, null, 2));

  try {
    const result = await dynamodb.put(params).promise();
    console.log("DynamoDB put result:", result);
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*", // or "http://localhost:8081"
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ message: "Success adding like" }),
    };
  } catch (error) {
    console.error("DynamoDB put error:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*", // or "http://localhost:8081"
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ message: "Failed adding like", error: error.message }),
    };
  }
};
import AWS from "aws-sdk";
import jwt from "jsonwebtoken";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";

dotenv.config();

const CLOUDFRONT_URL = process.env.CLOUDFRONT_URL; // e.g., "https://dxxxxxx.cloudfront.net"
const SECRET_ARN = process.env.SECRET_ARN; // ARN of Secrets Manager storing the CloudFront key
const BUCKET_NAME = process.env.BUCKET_NAME;

const secretsManager = new AWS.SecretsManager();
const s3 = new AWS.S3();

let privateKey = "";
let keyPairId = "";

// Load CloudFront private key from AWS Secrets Manager
async function loadSecrets() {
  try {
    const secretData = await secretsManager.getSecretValue({ SecretId: SECRET_ARN }).promise();
    console.log("Secret fetched:", secretData);
    const secret = JSON.parse(secretData.SecretString);
    privateKey = secret.cloudfront_private_key;
    keyPairId = secret.cloudfront_key_pair_id;
    // Reformat the private key back to PEM format (multiline)
    const base64Key = privateKey.replace(/\s+/g, '');  // Remove all whitespace (in case the key has any)
    const keyWithHeaderFooter = `-----BEGIN PRIVATE KEY-----\n` +
                                base64Key.match(/.{1,64}/g).join('\n') +  // Add newlines every 64 characters
                                `\n-----END PRIVATE KEY-----`;
    privateKey = keyWithHeaderFooter; 
    console.log("Private Key and Key Pair ID loaded successfully");
  } catch (error) {
    console.error("Error loading secrets:", error);
    throw error;  // Ensure the error is thrown to make debugging easier
  }
}

// Verify Cognito Token
async function verifyCognitoToken(token) {
  try {
    console.log("Verifying Cognito token...");
    const decoded = jwt.decode(token, { complete: true });
    if (!decoded) throw new Error("Invalid token");
    console.log("Token verified successfully");
    return true;
  } catch (error) {
    console.error("Invalid Cognito Token:", error);
    return false;
  }
}

// Generate CloudFront Signed URL
function generateSignedUrl(filePath) {
  try {
    const expires = Math.floor(Date.now() / 1000) + 3600; // 1-hour expiry

    const cloudFrontUrl = `${CLOUDFRONT_URL}/${filePath}`;
    const cloudFront = new AWS.CloudFront.Signer(keyPairId, privateKey);
    const signedUrl = cloudFront.getSignedUrl({
      url: cloudFrontUrl,
      expires: expires
  });
  console.log(signedUrl);
  return signedUrl;

  } catch (error) {
    console.error("Error in signing process:", error);
    return null;
  }
}

// Lambda Handler
export const handler = async (event) => {
  try {
    console.log("Lambda function invoked");
    if (!privateKey) await loadSecrets();

    console.log(`Secrets loaded start authorizing ${privateKey}`);
    console.log("Event headers:", event.headers);
    const token = event.headers.Authorization?.split(" ")[1];
    console.log("Token from headers:", token);
    if (!token || !(await verifyCognitoToken(token))) {
      console.error("No Authorization token found");
      return {
        statusCode: 401,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
          "Access-Control-Allow-Methods": "OPTIONS, GET",
        },
        body: JSON.stringify({ error: "Unauthorized" }),
      };
    }
    console.log(`Received token: ${token}`);

    // Get list of files from S3
    const params = {
    Bucket: BUCKET_NAME
    };

    console.log(`Getting all S3 files from bucket: ${BUCKET_NAME}`);
    const s3Data = await s3.listObjectsV2(params).promise();
    if (!s3Data.Contents.length) {
      console.error("No files found in the S3 bucket.");
        return {
            statusCode: 404,
            body: JSON.stringify({ error: "No files found" })
        };
    }

    // Generate signed URLs for each file
    console.log(`Generating signed URLs`);
    const signedUrls = s3Data.Contents.map(file => (generateSignedUrl(file.Key)));

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "OPTIONS, GET",
      },
      body: JSON.stringify({ signedUrls }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "OPTIONS, GET",
      },
      body: JSON.stringify({ error: "Failed to generate signed URL" }),
    };
  }
};

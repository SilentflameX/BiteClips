import AWS from "aws-sdk";
import jwt from "jsonwebtoken";
const dynamodb = new AWS.DynamoDB.DocumentClient();

// Verify Cognito Token
async function verifyCognitoToken(token) {
  try {
    console.log("Verifying Cognito token...");
    const decoded = jwt.decode(token, { complete: true });
    if (!decoded) throw new Error("Invalid token");
    console.log("Token verified successfully");
    return true;
  } catch (error) {
    console.error("Invalid Cognito Token:", error);
    return false;
  }
}


export const handler = async (event) => {
  const userId = event.queryStringParameters.userId; // Get userId from query params
  console.log("Received userId:", userId);  // Debugging: log the userId

  const token = event.headers.Authorization?.split(" ")[1];
  console.log("Token from headers:", token);

  if(!await verifyCognitoToken(token))
  {
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*", // or "http://localhost:8081"
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ message: "Invalid token", error: error.message }), // Include error message in response
    };
  }

  const params = {
    TableName: "UserLikedVideos",
    KeyConditionExpression: "UserID = :userId",
    ExpressionAttributeValues: {
      ":userId": userId,
    },
  };

  try {
    console.log("Query params:", params);  // Debugging: log the query params before execution

    const result = await dynamodb.query(params).promise();

    console.log("Query result:", result);  // Debugging: log the result of the query

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*", // or "http://localhost:8081"
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ likedVideos: result.Items }),
    };
  } catch (error) {
    console.error("DynamoDB Query Error:", error);  // Debugging: log the error in case of failure

    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*", // or "http://localhost:8081"
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ message: "Failed to fetch liked videos", error: error.message }), // Include error message in response
    };
  }
};
